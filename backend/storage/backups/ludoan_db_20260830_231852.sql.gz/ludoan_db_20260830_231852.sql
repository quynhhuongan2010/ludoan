-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: ludoan_db
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'binh_thuong',
  `is_pinned` tinyint(1) NOT NULL DEFAULT '0',
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `author_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `ix_announcements_is_public` (`is_public`),
  KEY `ix_announcements_priority` (`priority`),
  KEY `ix_announcements_is_pinned` (`is_pinned`),
  KEY `ix_announcements_id` (`id`),
  CONSTRAINT `announcements_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `command_meeting_attendees`
--

DROP TABLE IF EXISTS `command_meeting_attendees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `command_meeting_attendees` (
  `id` int NOT NULL AUTO_INCREMENT,
  `meeting_id` int NOT NULL,
  `user_id` int NOT NULL,
  `unit_id` int DEFAULT NULL,
  `attendance` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'chua_diem_danh',
  `absence_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contribution_note` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_meeting_user_attendee` (`meeting_id`,`user_id`),
  KEY `unit_id` (`unit_id`),
  KEY `ix_command_meeting_attendees_id` (`id`),
  KEY `ix_command_meeting_attendees_user_id` (`user_id`),
  KEY `ix_command_meeting_attendees_meeting_id` (`meeting_id`),
  CONSTRAINT `command_meeting_attendees_ibfk_1` FOREIGN KEY (`meeting_id`) REFERENCES `command_meetings` (`id`),
  CONSTRAINT `command_meeting_attendees_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `command_meeting_attendees_ibfk_3` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `command_meeting_attendees`
--

LOCK TABLES `command_meeting_attendees` WRITE;
/*!40000 ALTER TABLE `command_meeting_attendees` DISABLE KEYS */;
/*!40000 ALTER TABLE `command_meeting_attendees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `command_meetings`
--

DROP TABLE IF EXISTS `command_meetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `command_meetings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting_link` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agenda` text COLLATE utf8mb4_unicode_ci,
  `minutes` text COLLATE utf8mb4_unicode_ci,
  `attachment_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_type` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sap_dien_ra',
  `classification` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mat',
  `created_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `created_by_id` (`created_by_id`),
  KEY `ix_command_meetings_start_time` (`start_time`),
  KEY `ix_command_meetings_id` (`id`),
  KEY `ix_command_meetings_status` (`status`),
  CONSTRAINT `command_meetings_ibfk_1` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `command_meetings`
--

LOCK TABLES `command_meetings` WRITE;
/*!40000 ALTER TABLE `command_meetings` DISABLE KEYS */;
/*!40000 ALTER TABLE `command_meetings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `command_messages`
--

DROP TABLE IF EXISTS `command_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `command_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `thread_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `ix_command_messages_thread_id` (`thread_id`),
  KEY `ix_command_messages_id` (`id`),
  CONSTRAINT `command_messages_ibfk_1` FOREIGN KEY (`thread_id`) REFERENCES `command_threads` (`id`),
  CONSTRAINT `command_messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `command_messages`
--

LOCK TABLES `command_messages` WRITE;
/*!40000 ALTER TABLE `command_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `command_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `command_thread_reads`
--

DROP TABLE IF EXISTS `command_thread_reads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `command_thread_reads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `thread_id` int NOT NULL,
  `user_id` int NOT NULL,
  `last_read_message_id` int NOT NULL DEFAULT '0',
  `last_read_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_command_thread_user_read` (`thread_id`,`user_id`),
  KEY `ix_command_thread_reads_thread_id` (`thread_id`),
  KEY `ix_command_thread_reads_id` (`id`),
  KEY `ix_command_thread_reads_user_id` (`user_id`),
  CONSTRAINT `command_thread_reads_ibfk_1` FOREIGN KEY (`thread_id`) REFERENCES `command_threads` (`id`),
  CONSTRAINT `command_thread_reads_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `command_thread_reads`
--

LOCK TABLES `command_thread_reads` WRITE;
/*!40000 ALTER TABLE `command_thread_reads` DISABLE KEYS */;
/*!40000 ALTER TABLE `command_thread_reads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `command_threads`
--

DROP TABLE IF EXISTS `command_threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `command_threads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classification` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mat',
  `created_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `last_message_at` datetime DEFAULT NULL,
  `is_closed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `created_by_id` (`created_by_id`),
  KEY `ix_command_threads_is_closed` (`is_closed`),
  KEY `ix_command_threads_id` (`id`),
  CONSTRAINT `command_threads_ibfk_1` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `command_threads`
--

LOCK TABLES `command_threads` WRITE;
/*!40000 ALTER TABLE `command_threads` DISABLE KEYS */;
/*!40000 ALTER TABLE `command_threads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_acknowledgements`
--

DROP TABLE IF EXISTS `directive_acknowledgements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_acknowledgements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `directive_id` int NOT NULL,
  `user_id` int NOT NULL,
  `acknowledged_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_directive_user_ack` (`directive_id`,`user_id`),
  KEY `ix_directive_acknowledgements_user_id` (`user_id`),
  KEY `ix_directive_acknowledgements_directive_id` (`directive_id`),
  KEY `ix_directive_acknowledgements_id` (`id`),
  CONSTRAINT `directive_acknowledgements_ibfk_1` FOREIGN KEY (`directive_id`) REFERENCES `directives` (`id`),
  CONSTRAINT `directive_acknowledgements_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_acknowledgements`
--

LOCK TABLES `directive_acknowledgements` WRITE;
/*!40000 ALTER TABLE `directive_acknowledgements` DISABLE KEYS */;
/*!40000 ALTER TABLE `directive_acknowledgements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_assignment_targets`
--

DROP TABLE IF EXISTS `directive_assignment_targets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_assignment_targets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assignment_id` int NOT NULL,
  `unit_id` int NOT NULL,
  `assignee_id` int DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'chua_nop',
  `submitted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_assignment_unit_assignee` (`assignment_id`,`unit_id`,`assignee_id`),
  KEY `ix_directive_assignment_targets_id` (`id`),
  KEY `ix_directive_assignment_targets_unit_id` (`unit_id`),
  KEY `ix_directive_assignment_targets_assignment_id` (`assignment_id`),
  KEY `ix_directive_assignment_targets_status` (`status`),
  KEY `ix_directive_assignment_targets_assignee_id` (`assignee_id`),
  CONSTRAINT `directive_assignment_targets_ibfk_1` FOREIGN KEY (`assignment_id`) REFERENCES `directive_assignments` (`id`),
  CONSTRAINT `directive_assignment_targets_ibfk_2` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`),
  CONSTRAINT `directive_assignment_targets_ibfk_3` FOREIGN KEY (`assignee_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_assignment_targets`
--

LOCK TABLES `directive_assignment_targets` WRITE;
/*!40000 ALTER TABLE `directive_assignment_targets` DISABLE KEYS */;
/*!40000 ALTER TABLE `directive_assignment_targets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_assignments`
--

DROP TABLE IF EXISTS `directive_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_assignments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `directive_id` int DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `due_date` date DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'chua_giao',
  `created_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `created_by_id` (`created_by_id`),
  KEY `ix_directive_assignments_id` (`id`),
  KEY `ix_directive_assignments_status` (`status`),
  KEY `ix_directive_assignments_directive_id` (`directive_id`),
  CONSTRAINT `directive_assignments_ibfk_1` FOREIGN KEY (`directive_id`) REFERENCES `directives` (`id`),
  CONSTRAINT `directive_assignments_ibfk_2` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_assignments`
--

LOCK TABLES `directive_assignments` WRITE;
/*!40000 ALTER TABLE `directive_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `directive_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_messages`
--

DROP TABLE IF EXISTS `directive_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `thread_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `ix_directive_messages_id` (`id`),
  KEY `ix_directive_messages_thread_id` (`thread_id`),
  CONSTRAINT `directive_messages_ibfk_1` FOREIGN KEY (`thread_id`) REFERENCES `directive_threads` (`id`),
  CONSTRAINT `directive_messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_messages`
--

LOCK TABLES `directive_messages` WRITE;
/*!40000 ALTER TABLE `directive_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `directive_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_submissions`
--

DROP TABLE IF EXISTS `directive_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_submissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `target_id` int NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `review_result` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `review_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewed_by_id` int DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `submitted_by_id` (`submitted_by_id`),
  KEY `reviewed_by_id` (`reviewed_by_id`),
  KEY `ix_directive_submissions_target_id` (`target_id`),
  KEY `ix_directive_submissions_id` (`id`),
  CONSTRAINT `directive_submissions_ibfk_1` FOREIGN KEY (`target_id`) REFERENCES `directive_assignment_targets` (`id`),
  CONSTRAINT `directive_submissions_ibfk_2` FOREIGN KEY (`submitted_by_id`) REFERENCES `users` (`id`),
  CONSTRAINT `directive_submissions_ibfk_3` FOREIGN KEY (`reviewed_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_submissions`
--

LOCK TABLES `directive_submissions` WRITE;
/*!40000 ALTER TABLE `directive_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `directive_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_thread_reads`
--

DROP TABLE IF EXISTS `directive_thread_reads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_thread_reads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `thread_id` int NOT NULL,
  `user_id` int NOT NULL,
  `last_read_message_id` int NOT NULL DEFAULT '0',
  `last_read_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_directive_thread_user_read` (`thread_id`,`user_id`),
  KEY `ix_directive_thread_reads_user_id` (`user_id`),
  KEY `ix_directive_thread_reads_id` (`id`),
  KEY `ix_directive_thread_reads_thread_id` (`thread_id`),
  CONSTRAINT `directive_thread_reads_ibfk_1` FOREIGN KEY (`thread_id`) REFERENCES `directive_threads` (`id`),
  CONSTRAINT `directive_thread_reads_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_thread_reads`
--

LOCK TABLES `directive_thread_reads` WRITE;
/*!40000 ALTER TABLE `directive_thread_reads` DISABLE KEYS */;
/*!40000 ALTER TABLE `directive_thread_reads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_threads`
--

DROP TABLE IF EXISTS `directive_threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_threads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unit_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `last_message_at` datetime DEFAULT NULL,
  `is_closed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `created_by_id` (`created_by_id`),
  KEY `ix_directive_threads_unit_id` (`unit_id`),
  KEY `ix_directive_threads_is_closed` (`is_closed`),
  KEY `ix_directive_threads_id` (`id`),
  CONSTRAINT `directive_threads_ibfk_1` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`),
  CONSTRAINT `directive_threads_ibfk_2` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_threads`
--

LOCK TABLES `directive_threads` WRITE;
/*!40000 ALTER TABLE `directive_threads` DISABLE KEYS */;
/*!40000 ALTER TABLE `directive_threads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directives`
--

DROP TABLE IF EXISTS `directives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directives` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'nhap',
  `classification` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noi_bo',
  `author_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `ix_directives_id` (`id`),
  KEY `ix_directives_classification` (`classification`),
  KEY `ix_directives_status` (`status`),
  CONSTRAINT `directives_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directives`
--

LOCK TABLES `directives` WRITE;
/*!40000 ALTER TABLE `directives` DISABLE KEYS */;
/*!40000 ALTER TABLE `directives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dispatch_acknowledgements`
--

DROP TABLE IF EXISTS `dispatch_acknowledgements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dispatch_acknowledgements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dispatch_id` int NOT NULL,
  `user_id` int NOT NULL,
  `acknowledged_at` datetime NOT NULL DEFAULT (now()),
  `response_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dispatch_user_ack` (`dispatch_id`,`user_id`),
  KEY `ix_dispatch_acknowledgements_user_id` (`user_id`),
  KEY `ix_dispatch_acknowledgements_id` (`id`),
  KEY `ix_dispatch_acknowledgements_dispatch_id` (`dispatch_id`),
  CONSTRAINT `dispatch_acknowledgements_ibfk_1` FOREIGN KEY (`dispatch_id`) REFERENCES `official_dispatches` (`id`),
  CONSTRAINT `dispatch_acknowledgements_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispatch_acknowledgements`
--

LOCK TABLES `dispatch_acknowledgements` WRITE;
/*!40000 ALTER TABLE `dispatch_acknowledgements` DISABLE KEYS */;
/*!40000 ALTER TABLE `dispatch_acknowledgements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `category` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int NOT NULL,
  `content_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classification` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noi_bo',
  `uploaded_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `uploaded_by_id` (`uploaded_by_id`),
  KEY `ix_documents_category` (`category`),
  KEY `ix_documents_classification` (`classification`),
  KEY `ix_documents_id` (`id`),
  CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`uploaded_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `duty_schedules`
--

DROP TABLE IF EXISTS `duty_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `duty_schedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `duty_date` date NOT NULL,
  `shift` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duty_officer` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `ix_duty_schedules_duty_date` (`duty_date`),
  KEY `ix_duty_schedules_id` (`id`),
  CONSTRAINT `duty_schedules_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `duty_schedules`
--

LOCK TABLES `duty_schedules` WRITE;
/*!40000 ALTER TABLE `duty_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `duty_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `education_materials`
--

DROP TABLE IF EXISTS `education_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `education_materials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_label` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `ix_education_materials_category` (`category`),
  KEY `ix_education_materials_id` (`id`),
  CONSTRAINT `education_materials_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `education_materials`
--

LOCK TABLES `education_materials` WRITE;
/*!40000 ALTER TABLE `education_materials` DISABLE KEYS */;
/*!40000 ALTER TABLE `education_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_items_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `official_dispatches`
--

DROP TABLE IF EXISTS `official_dispatches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `official_dispatches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `direction` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'den',
  `dispatch_number` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `issuing_org` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receiving_org` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issued_date` date DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'moi',
  `classification` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mat',
  `note` text COLLATE utf8mb4_unicode_ci,
  `attachment_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_type` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dispatch_direction_number` (`direction`,`dispatch_number`),
  KEY `created_by_id` (`created_by_id`),
  KEY `ix_official_dispatches_dispatch_number` (`dispatch_number`),
  KEY `ix_official_dispatches_id` (`id`),
  KEY `ix_official_dispatches_direction` (`direction`),
  KEY `ix_official_dispatches_status` (`status`),
  CONSTRAINT `official_dispatches_ibfk_1` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `official_dispatches`
--

LOCK TABLES `official_dispatches` WRITE;
/*!40000 ALTER TABLE `official_dispatches` DISABLE KEYS */;
/*!40000 ALTER TABLE `official_dispatches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cover_image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cho_duyet',
  `review_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewed_by_id` int DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `classification` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noi_bo',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `author_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `reviewed_by_id` (`reviewed_by_id`),
  KEY `author_id` (`author_id`),
  KEY `ix_posts_status` (`status`),
  KEY `ix_posts_id` (`id`),
  KEY `ix_posts_classification` (`classification`),
  KEY `ix_posts_is_featured` (`is_featured`),
  KEY `ix_posts_category` (`category`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`reviewed_by_id`) REFERENCES `users` (`id`),
  CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_kind` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'phong_ban',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_units_name` (`name`),
  KEY `ix_units_id` (`id`),
  KEY `ix_units_unit_kind` (`unit_kind`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'Tiểu đoàn 1','tieu_doan',NULL,1,'2026-08-30 19:22:37'),(3,'Đại đội 5','dai_doi',NULL,1,'2026-08-30 19:37:54'),(6,'Ban chỉ huy Lữ đoàn','bch_lu_doan','Lữ trưởng, Chính uỷ, các Phó Lữ trưởng, Phó Chính uỷ',1,'2026-08-30 21:26:25'),(7,'Cấp uỷ – Đảng bộ Lữ đoàn','cap_uy','Cấp uỷ, Đảng bộ Lữ đoàn',1,'2026-08-30 21:26:25'),(8,'Phòng Tham mưu','phong_ban','Cơ quan tham mưu — đầu mối nhận và triển khai nhiệm vụ tác chiến, huấn luyện, SSCĐ',1,'2026-08-30 21:26:25'),(9,'Phòng Chính trị','phong_ban','Cơ quan chính trị — đầu mối công tác đảng, công tác chính trị, tuyên huấn',1,'2026-08-30 21:26:25'),(10,'Phòng Hậu cần – Kỹ thuật','phong_ban','Cơ quan hậu cần – kỹ thuật — đầu mối bảo đảm vật chất, kỹ thuật, quân y',1,'2026-08-30 21:26:25'),(11,'Tiểu đoàn 2','tieu_doan','Đầu mối tiểu đoàn — nhận nhiệm vụ và báo cáo tiến độ',1,'2026-08-30 21:26:25'),(12,'Trạm bảo đảm','tram','Trạm bảo đảm thông tin',1,'2026-08-30 21:26:25'),(13,'Trung tâm 2','phong_ban','Trung tâm 2 — đầu mối trực thuộc',1,'2026-08-30 21:26:25');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hashed_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `clearance` tinyint(1) NOT NULL DEFAULT '0',
  `unit_id` int DEFAULT NULL,
  `directive_channel_access` tinyint(1) NOT NULL DEFAULT '0',
  `command_channel_access` tinyint(1) NOT NULL DEFAULT '0',
  `is_system` tinyint(1) NOT NULL DEFAULT '0',
  `must_change_password` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_users_username` (`username`),
  KEY `ix_users_id` (`id`),
  KEY `ix_users_unit_id` (`unit_id`),
  CONSTRAINT `fk_users_unit` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2b$12$aV77jHsrBjJhss51ieW6OuNqn9NOnkSWd8U28KyiLkVMcGT424YjK','Quản trị hệ thống','admin',1,1,NULL,0,0,1,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'ludoan_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-30 23:18:52
