-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: ludoan_db
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'binh_thuong',
  `is_pinned` tinyint(1) NOT NULL DEFAULT '0',
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `author_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `ix_announcements_is_public` (`is_public`),
  KEY `ix_announcements_priority` (`priority`),
  KEY `ix_announcements_is_pinned` (`is_pinned`),
  KEY `ix_announcements_id` (`id`),
  CONSTRAINT `announcements_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `actor_id` int DEFAULT NULL,
  `actor_username` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actor_full_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actor_role` int DEFAULT NULL,
  `action` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_success` tinyint(1) NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `ix_audit_logs_created_at` (`created_at`),
  KEY `ix_audit_logs_id` (`id`),
  KEY `ix_audit_logs_action` (`action`),
  KEY `ix_audit_logs_target_type` (`target_type`),
  KEY `ix_audit_logs_actor_id` (`actor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,'2026-09-06 02:15:36',NULL,NULL,NULL,NULL,'LOGIN_FAILED','auth',NULL,'thammuu123','127.0.0.1',0,'Sai tên đăng nhập hoặc mật khẩu'),(2,'2026-09-06 02:20:36',1,'admin','Quản trị hệ thống',0,'auth_login','auth','1','admin','127.0.0.1',1,'Đăng nhập thành công'),(3,'2026-09-06 04:01:40',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_test.xlsx',NULL,1,'Đã nhập thành công 2/2 tài khoản từ file danh_sach_test.xlsx'),(4,'2026-09-06 04:01:40',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_test.docx',NULL,1,'Đã nhập thành công 1/1 tài khoản từ file danh_sach_test.docx'),(5,'2026-09-06 04:01:40',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_dup.xlsx',NULL,1,'Đã nhập thành công 0/2 tài khoản từ file danh_sach_dup.xlsx'),(6,'2026-09-06 04:02:17',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_test.xlsx',NULL,1,'Đã nhập thành công 0/2 tài khoản từ file danh_sach_test.xlsx'),(7,'2026-09-06 04:02:32',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_test.xlsx',NULL,1,'Đã nhập thành công 2/2 tài khoản từ file danh_sach_test.xlsx'),(8,'2026-09-06 04:02:32',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_test.docx',NULL,1,'Đã nhập thành công 1/1 tài khoản từ file danh_sach_test.docx'),(9,'2026-09-06 04:02:32',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_dup.xlsx',NULL,1,'Đã nhập thành công 0/2 tài khoản từ file danh_sach_dup.xlsx'),(10,'2026-09-06 04:02:33',1,'admin','Quản trị hệ thống',0,'user_purge_test_accounts','system',NULL,'Dọn dẹp tài khoản thử nghiệm',NULL,1,'Đã xoá 25 tài khoản thử nghiệm'),(11,'2026-09-06 04:02:54',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_test.xlsx',NULL,1,'Đã nhập thành công 2/2 tài khoản từ file danh_sach_test.xlsx'),(12,'2026-09-06 04:02:54',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_test.docx',NULL,1,'Đã nhập thành công 1/1 tài khoản từ file danh_sach_test.docx'),(13,'2026-09-06 04:02:54',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_dup.xlsx',NULL,1,'Đã nhập thành công 0/2 tài khoản từ file danh_sach_dup.xlsx'),(14,'2026-09-06 04:02:55',1,'admin','Quản trị hệ thống',0,'user_purge_test_accounts','system',NULL,'Dọn dẹp tài khoản thử nghiệm',NULL,1,'Đã xoá 21 tài khoản thử nghiệm'),(15,'2026-09-06 04:10:53',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_test.xlsx',NULL,1,'Đã nhập thành công 2/2 tài khoản từ file danh_sach_test.xlsx'),(16,'2026-09-06 04:10:53',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_test.docx',NULL,1,'Đã nhập thành công 1/1 tài khoản từ file danh_sach_test.docx'),(17,'2026-09-06 04:10:53',1,'admin','Quản trị hệ thống',0,'user_import_batch','system',NULL,'danh_sach_dup.xlsx',NULL,1,'Đã nhập thành công 0/2 tài khoản từ file danh_sach_dup.xlsx'),(18,'2026-09-06 04:10:54',1,'admin','Quản trị hệ thống',0,'user_purge_test_accounts','system',NULL,'Dọn dẹp tài khoản thử nghiệm',NULL,1,'Đã xoá 21 tài khoản thử nghiệm'),(19,'2026-09-06 06:37:25',1,'admin','Quản trị hệ thống',0,'auth_login','auth','1','admin','127.0.0.1',1,'Đăng nhập thành công'),(20,'2026-09-06 06:50:51',NULL,NULL,NULL,NULL,'LOGIN_FAILED','auth',NULL,'le quynh','127.0.0.1',0,'Sai tên đăng nhập hoặc mật khẩu'),(21,'2026-09-06 06:51:59',NULL,NULL,NULL,NULL,'LOGIN_FAILED','auth',NULL,'quynle','127.0.0.1',0,'Sai tên đăng nhập hoặc mật khẩu'),(22,'2026-09-06 06:52:20',NULL,NULL,NULL,NULL,'LOGIN_FAILED','auth',NULL,'lequynh','127.0.0.1',0,'Sai tên đăng nhập hoặc mật khẩu'),(23,'2026-09-06 06:53:07',NULL,NULL,NULL,NULL,'LOGIN_FAILED','auth',NULL,'lutruong21','127.0.0.1',0,'Sai tên đăng nhập hoặc mật khẩu'),(24,'2026-09-06 06:55:53',NULL,NULL,NULL,NULL,'LOGIN_FAILED','auth',NULL,'lutruong21','127.0.0.1',0,'Sai tên đăng nhập hoặc mật khẩu'),(25,'2026-09-06 06:55:57',NULL,NULL,NULL,NULL,'LOGIN_LOCKOUT_TRIGGERED','auth',NULL,'lutruong21','127.0.0.1',0,'Kích hoạt khóa tạm thời 15 phút do nhập sai mật khẩu 5 lần liên tiếp');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_conversations`
--

DROP TABLE IF EXISTS `chat_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_conversations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `last_message_at` datetime DEFAULT NULL,
  `last_message_preview` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_archived` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by_id` (`created_by_id`),
  KEY `ix_chat_conversations_last_message_at` (`last_message_at`),
  KEY `ix_chat_conversations_type` (`type`),
  KEY `ix_chat_conversations_id` (`id`),
  CONSTRAINT `chat_conversations_ibfk_1` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_conversations`
--

LOCK TABLES `chat_conversations` WRITE;
/*!40000 ALTER TABLE `chat_conversations` DISABLE KEYS */;
INSERT INTO `chat_conversations` VALUES (1,'direct',NULL,1,'2026-09-06 13:38:23',NULL,NULL,0);
/*!40000 ALTER TABLE `chat_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversation_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `ix_chat_messages_sender_id` (`sender_id`),
  KEY `ix_chat_messages_created_at` (`created_at`),
  KEY `ix_chat_messages_conversation_id` (`conversation_id`),
  KEY `ix_chat_messages_id` (`id`),
  CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chat_messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_participants`
--

DROP TABLE IF EXISTS `chat_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_participants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversation_id` int NOT NULL,
  `user_id` int NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `joined_at` datetime NOT NULL DEFAULT (now()),
  `last_read_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_participant` (`conversation_id`,`user_id`),
  KEY `ix_chat_participants_conversation_id` (`conversation_id`),
  KEY `ix_chat_participants_user_id` (`user_id`),
  KEY `ix_chat_participants_id` (`id`),
  CONSTRAINT `chat_participants_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chat_participants_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_participants`
--

LOCK TABLES `chat_participants` WRITE;
/*!40000 ALTER TABLE `chat_participants` DISABLE KEYS */;
INSERT INTO `chat_participants` VALUES (1,1,1,1,'2026-09-06 13:38:23','2026-09-06 13:38:23'),(2,1,174,0,'2026-09-06 13:38:23',NULL);
/*!40000 ALTER TABLE `chat_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `command_messages`
--

DROP TABLE IF EXISTS `command_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `command_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `thread_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `ix_command_messages_thread_id` (`thread_id`),
  KEY `ix_command_messages_id` (`id`),
  CONSTRAINT `command_messages_ibfk_1` FOREIGN KEY (`thread_id`) REFERENCES `command_threads` (`id`),
  CONSTRAINT `command_messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `command_messages`
--

LOCK TABLES `command_messages` WRITE;
/*!40000 ALTER TABLE `command_messages` DISABLE KEYS */;
INSERT INTO `command_messages` VALUES (19,19,1,'De nghi Cap uy cho y kien phuong an kien toan can bo Dai doi 5 (minh hoa).',NULL,'2026-09-03 23:35:20');
/*!40000 ALTER TABLE `command_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `command_thread_documents`
--

DROP TABLE IF EXISTS `command_thread_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `command_thread_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `thread_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visibility` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'chung',
  `file_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int NOT NULL DEFAULT '0',
  `content_type` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploaded_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `uploaded_by_id` (`uploaded_by_id`),
  KEY `ix_command_thread_documents_thread_id` (`thread_id`),
  KEY `ix_command_thread_documents_id` (`id`),
  CONSTRAINT `command_thread_documents_ibfk_1` FOREIGN KEY (`thread_id`) REFERENCES `command_threads` (`id`),
  CONSTRAINT `command_thread_documents_ibfk_2` FOREIGN KEY (`uploaded_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `command_thread_documents`
--

LOCK TABLES `command_thread_documents` WRITE;
/*!40000 ALTER TABLE `command_thread_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `command_thread_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `command_thread_members`
--

DROP TABLE IF EXISTS `command_thread_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `command_thread_members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `thread_id` int NOT NULL,
  `user_id` int NOT NULL,
  `added_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_command_thread_member` (`thread_id`,`user_id`),
  KEY `ix_command_thread_members_thread_id` (`thread_id`),
  KEY `ix_command_thread_members_user_id` (`user_id`),
  KEY `ix_command_thread_members_id` (`id`),
  CONSTRAINT `command_thread_members_ibfk_1` FOREIGN KEY (`thread_id`) REFERENCES `command_threads` (`id`),
  CONSTRAINT `command_thread_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `command_thread_members`
--

LOCK TABLES `command_thread_members` WRITE;
/*!40000 ALTER TABLE `command_thread_members` DISABLE KEYS */;
INSERT INTO `command_thread_members` VALUES (15,19,1,'2026-09-03 23:35:20');
/*!40000 ALTER TABLE `command_thread_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `command_thread_minutes`
--

DROP TABLE IF EXISTS `command_thread_minutes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `command_thread_minutes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `thread_id` int NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_count` int NOT NULL DEFAULT '0',
  `generated_by_id` int NOT NULL,
  `generated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `generated_by_id` (`generated_by_id`),
  KEY `ix_command_thread_minutes_id` (`id`),
  KEY `ix_command_thread_minutes_thread_id` (`thread_id`),
  CONSTRAINT `command_thread_minutes_ibfk_1` FOREIGN KEY (`thread_id`) REFERENCES `command_threads` (`id`),
  CONSTRAINT `command_thread_minutes_ibfk_2` FOREIGN KEY (`generated_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `command_thread_minutes`
--

LOCK TABLES `command_thread_minutes` WRITE;
/*!40000 ALTER TABLE `command_thread_minutes` DISABLE KEYS */;
/*!40000 ALTER TABLE `command_thread_minutes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `command_thread_reads`
--

DROP TABLE IF EXISTS `command_thread_reads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `command_thread_reads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `thread_id` int NOT NULL,
  `user_id` int NOT NULL,
  `last_read_message_id` int NOT NULL DEFAULT '0',
  `last_read_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_command_thread_user_read` (`thread_id`,`user_id`),
  KEY `ix_command_thread_reads_thread_id` (`thread_id`),
  KEY `ix_command_thread_reads_id` (`id`),
  KEY `ix_command_thread_reads_user_id` (`user_id`),
  CONSTRAINT `command_thread_reads_ibfk_1` FOREIGN KEY (`thread_id`) REFERENCES `command_threads` (`id`),
  CONSTRAINT `command_thread_reads_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `command_thread_reads`
--

LOCK TABLES `command_thread_reads` WRITE;
/*!40000 ALTER TABLE `command_thread_reads` DISABLE KEYS */;
INSERT INTO `command_thread_reads` VALUES (21,19,1,19,'2026-09-03 23:36:06');
/*!40000 ALTER TABLE `command_thread_reads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `command_threads`
--

DROP TABLE IF EXISTS `command_threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `command_threads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classification` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mat',
  `created_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `last_message_at` datetime DEFAULT NULL,
  `is_closed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `created_by_id` (`created_by_id`),
  KEY `ix_command_threads_is_closed` (`is_closed`),
  KEY `ix_command_threads_id` (`id`),
  CONSTRAINT `command_threads_ibfk_1` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `command_threads`
--

LOCK TABLES `command_threads` WRITE;
/*!40000 ALTER TABLE `command_threads` DISABLE KEYS */;
INSERT INTO `command_threads` VALUES (19,'(demo) Trao doi cong tac can bo quy III/2026','mat',1,'2026-09-03 23:35:20','2026-09-03 23:35:20',1);
/*!40000 ALTER TABLE `command_threads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_books`
--

DROP TABLE IF EXISTS `contact_books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_books` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `column_headers` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `row_count` int NOT NULL DEFAULT '0',
  `created_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `created_by_id` (`created_by_id`),
  KEY `ix_contact_books_id` (`id`),
  CONSTRAINT `contact_books_ibfk_1` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_books`
--

LOCK TABLES `contact_books` WRITE;
/*!40000 ALTER TABLE `contact_books` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `book_id` int NOT NULL,
  `row_index` int NOT NULL DEFAULT '0',
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extra` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `search_blob` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_contacts_id` (`id`),
  KEY `ix_contacts_book_id` (`book_id`),
  CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `contact_books` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_acknowledgements`
--

DROP TABLE IF EXISTS `directive_acknowledgements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_acknowledgements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `directive_id` int NOT NULL,
  `user_id` int NOT NULL,
  `acknowledged_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_directive_user_ack` (`directive_id`,`user_id`),
  KEY `ix_directive_acknowledgements_user_id` (`user_id`),
  KEY `ix_directive_acknowledgements_directive_id` (`directive_id`),
  KEY `ix_directive_acknowledgements_id` (`id`),
  CONSTRAINT `directive_acknowledgements_ibfk_1` FOREIGN KEY (`directive_id`) REFERENCES `directives` (`id`),
  CONSTRAINT `directive_acknowledgements_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_acknowledgements`
--

LOCK TABLES `directive_acknowledgements` WRITE;
/*!40000 ALTER TABLE `directive_acknowledgements` DISABLE KEYS */;
INSERT INTO `directive_acknowledgements` VALUES (1,7,1,'2026-09-03 21:22:46');
/*!40000 ALTER TABLE `directive_acknowledgements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_assignment_targets`
--

DROP TABLE IF EXISTS `directive_assignment_targets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_assignment_targets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assignment_id` int NOT NULL,
  `unit_id` int NOT NULL,
  `assignee_id` int DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'chua_nop',
  `submitted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_assignment_unit_assignee` (`assignment_id`,`unit_id`,`assignee_id`),
  KEY `ix_directive_assignment_targets_id` (`id`),
  KEY `ix_directive_assignment_targets_unit_id` (`unit_id`),
  KEY `ix_directive_assignment_targets_assignment_id` (`assignment_id`),
  KEY `ix_directive_assignment_targets_status` (`status`),
  KEY `ix_directive_assignment_targets_assignee_id` (`assignee_id`),
  CONSTRAINT `directive_assignment_targets_ibfk_1` FOREIGN KEY (`assignment_id`) REFERENCES `directive_assignments` (`id`),
  CONSTRAINT `directive_assignment_targets_ibfk_2` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`),
  CONSTRAINT `directive_assignment_targets_ibfk_3` FOREIGN KEY (`assignee_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_assignment_targets`
--

LOCK TABLES `directive_assignment_targets` WRITE;
/*!40000 ALTER TABLE `directive_assignment_targets` DISABLE KEYS */;
/*!40000 ALTER TABLE `directive_assignment_targets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_assignments`
--

DROP TABLE IF EXISTS `directive_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_assignments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `directive_id` int DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `due_date` date DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'chua_giao',
  `created_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `created_by_id` (`created_by_id`),
  KEY `ix_directive_assignments_id` (`id`),
  KEY `ix_directive_assignments_status` (`status`),
  KEY `ix_directive_assignments_directive_id` (`directive_id`),
  CONSTRAINT `directive_assignments_ibfk_1` FOREIGN KEY (`directive_id`) REFERENCES `directives` (`id`),
  CONSTRAINT `directive_assignments_ibfk_2` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_assignments`
--

LOCK TABLES `directive_assignments` WRITE;
/*!40000 ALTER TABLE `directive_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `directive_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_messages`
--

DROP TABLE IF EXISTS `directive_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `thread_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `ix_directive_messages_id` (`id`),
  KEY `ix_directive_messages_thread_id` (`thread_id`),
  CONSTRAINT `directive_messages_ibfk_1` FOREIGN KEY (`thread_id`) REFERENCES `directive_threads` (`id`),
  CONSTRAINT `directive_messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_messages`
--

LOCK TABLES `directive_messages` WRITE;
/*!40000 ALTER TABLE `directive_messages` DISABLE KEYS */;
INSERT INTO `directive_messages` VALUES (45,25,1,'Kinh bao cao Ban Chi huy: Dai doi 5 hoan thanh 100% noi dung tuan 35 (minh hoa).',NULL,'2026-09-03 23:35:20');
/*!40000 ALTER TABLE `directive_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_submissions`
--

DROP TABLE IF EXISTS `directive_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_submissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `target_id` int NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `review_result` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `review_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewed_by_id` int DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `submitted_by_id` (`submitted_by_id`),
  KEY `reviewed_by_id` (`reviewed_by_id`),
  KEY `ix_directive_submissions_target_id` (`target_id`),
  KEY `ix_directive_submissions_id` (`id`),
  CONSTRAINT `directive_submissions_ibfk_1` FOREIGN KEY (`target_id`) REFERENCES `directive_assignment_targets` (`id`),
  CONSTRAINT `directive_submissions_ibfk_2` FOREIGN KEY (`submitted_by_id`) REFERENCES `users` (`id`),
  CONSTRAINT `directive_submissions_ibfk_3` FOREIGN KEY (`reviewed_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_submissions`
--

LOCK TABLES `directive_submissions` WRITE;
/*!40000 ALTER TABLE `directive_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `directive_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_thread_reads`
--

DROP TABLE IF EXISTS `directive_thread_reads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_thread_reads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `thread_id` int NOT NULL,
  `user_id` int NOT NULL,
  `last_read_message_id` int NOT NULL DEFAULT '0',
  `last_read_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_directive_thread_user_read` (`thread_id`,`user_id`),
  KEY `ix_directive_thread_reads_user_id` (`user_id`),
  KEY `ix_directive_thread_reads_id` (`id`),
  KEY `ix_directive_thread_reads_thread_id` (`thread_id`),
  CONSTRAINT `directive_thread_reads_ibfk_1` FOREIGN KEY (`thread_id`) REFERENCES `directive_threads` (`id`),
  CONSTRAINT `directive_thread_reads_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_thread_reads`
--

LOCK TABLES `directive_thread_reads` WRITE;
/*!40000 ALTER TABLE `directive_thread_reads` DISABLE KEYS */;
INSERT INTO `directive_thread_reads` VALUES (35,25,1,45,'2026-09-06 09:48:00');
/*!40000 ALTER TABLE `directive_thread_reads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directive_threads`
--

DROP TABLE IF EXISTS `directive_threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directive_threads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unit_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `last_message_at` datetime DEFAULT NULL,
  `is_closed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `created_by_id` (`created_by_id`),
  KEY `ix_directive_threads_unit_id` (`unit_id`),
  KEY `ix_directive_threads_is_closed` (`is_closed`),
  KEY `ix_directive_threads_id` (`id`),
  CONSTRAINT `directive_threads_ibfk_1` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`),
  CONSTRAINT `directive_threads_ibfk_2` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directive_threads`
--

LOCK TABLES `directive_threads` WRITE;
/*!40000 ALTER TABLE `directive_threads` DISABLE KEYS */;
INSERT INTO `directive_threads` VALUES (25,3,'(demo) Bao cao SSCD tuan 35 - Dai doi 5',1,'2026-09-03 23:35:20','2026-09-03 23:35:20',1);
/*!40000 ALTER TABLE `directive_threads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directives`
--

DROP TABLE IF EXISTS `directives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directives` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'nhap',
  `classification` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noi_bo',
  `author_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `ix_directives_id` (`id`),
  KEY `ix_directives_classification` (`classification`),
  KEY `ix_directives_status` (`status`),
  CONSTRAINT `directives_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directives`
--

LOCK TABLES `directives` WRITE;
/*!40000 ALTER TABLE `directives` DISABLE KEYS */;
INSERT INTO `directives` VALUES (7,'Chỉ thị 01','Test','da_ban_hanh','noi_bo',1,'2026-09-03 21:21:31');
/*!40000 ALTER TABLE `directives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dispatch_acknowledgements`
--

DROP TABLE IF EXISTS `dispatch_acknowledgements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dispatch_acknowledgements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dispatch_id` int NOT NULL,
  `user_id` int NOT NULL,
  `acknowledged_at` datetime NOT NULL DEFAULT (now()),
  `response_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dispatch_user_ack` (`dispatch_id`,`user_id`),
  KEY `ix_dispatch_acknowledgements_user_id` (`user_id`),
  KEY `ix_dispatch_acknowledgements_id` (`id`),
  KEY `ix_dispatch_acknowledgements_dispatch_id` (`dispatch_id`),
  CONSTRAINT `dispatch_acknowledgements_ibfk_1` FOREIGN KEY (`dispatch_id`) REFERENCES `official_dispatches` (`id`),
  CONSTRAINT `dispatch_acknowledgements_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispatch_acknowledgements`
--

LOCK TABLES `dispatch_acknowledgements` WRITE;
/*!40000 ALTER TABLE `dispatch_acknowledgements` DISABLE KEYS */;
/*!40000 ALTER TABLE `dispatch_acknowledgements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `category` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int NOT NULL,
  `content_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classification` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noi_bo',
  `uploaded_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `uploaded_by_id` (`uploaded_by_id`),
  KEY `ix_documents_category` (`category`),
  KEY `ix_documents_classification` (`classification`),
  KEY `ix_documents_id` (`id`),
  CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`uploaded_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `duty_schedules`
--

DROP TABLE IF EXISTS `duty_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `duty_schedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `duty_date` date NOT NULL,
  `shift` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duty_officer` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `unit_id` int DEFAULT NULL,
  `duty_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'khac',
  `contact_phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `personnel_present` int DEFAULT NULL,
  `personnel_total` int DEFAULT NULL,
  `week_plan_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `ix_duty_schedules_duty_date` (`duty_date`),
  KEY `ix_duty_schedules_id` (`id`),
  KEY `fk_duty_schedules_unit_id` (`unit_id`),
  KEY `fk_duty_schedules_week_plan_id` (`week_plan_id`),
  CONSTRAINT `duty_schedules_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_duty_schedules_unit_id` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`),
  CONSTRAINT `fk_duty_schedules_week_plan_id` FOREIGN KEY (`week_plan_id`) REFERENCES `duty_week_plans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `duty_schedules`
--

LOCK TABLES `duty_schedules` WRITE;
/*!40000 ALTER TABLE `duty_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `duty_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `duty_shift_handovers`
--

DROP TABLE IF EXISTS `duty_shift_handovers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `duty_shift_handovers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `schedule_id` int NOT NULL,
  `giver_id` int NOT NULL,
  `giver_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiver_id` int DEFAULT NULL,
  `receiver_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handover_time` datetime NOT NULL DEFAULT (now()),
  `personnel_report` text COLLATE utf8mb4_unicode_ci,
  `equipment_status` text COLLATE utf8mb4_unicode_ci,
  `incident_log` text COLLATE utf8mb4_unicode_ci,
  `pending_tasks` text COLLATE utf8mb4_unicode_ci,
  `commander_note` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cho_nhan',
  `receiver_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acknowledged_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `ix_duty_shift_handovers_schedule_id` (`schedule_id`),
  KEY `ix_duty_shift_handovers_status` (`status`),
  KEY `ix_duty_shift_handovers_id` (`id`),
  KEY `ix_duty_shift_handovers_receiver_id` (`receiver_id`),
  KEY `ix_duty_shift_handovers_giver_id` (`giver_id`),
  CONSTRAINT `duty_shift_handovers_ibfk_1` FOREIGN KEY (`schedule_id`) REFERENCES `duty_schedules` (`id`),
  CONSTRAINT `duty_shift_handovers_ibfk_2` FOREIGN KEY (`giver_id`) REFERENCES `users` (`id`),
  CONSTRAINT `duty_shift_handovers_ibfk_3` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `duty_shift_handovers`
--

LOCK TABLES `duty_shift_handovers` WRITE;
/*!40000 ALTER TABLE `duty_shift_handovers` DISABLE KEYS */;
/*!40000 ALTER TABLE `duty_shift_handovers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `duty_week_plans`
--

DROP TABLE IF EXISTS `duty_week_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `duty_week_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unit_id` int NOT NULL,
  `week_start` date NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'nhap',
  `note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_by_id` int DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `reviewed_by_id` int DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `review_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_duty_week_plan_unit_week` (`unit_id`,`week_start`),
  KEY `submitted_by_id` (`submitted_by_id`),
  KEY `reviewed_by_id` (`reviewed_by_id`),
  KEY `author_id` (`author_id`),
  KEY `ix_duty_week_plans_status` (`status`),
  KEY `ix_duty_week_plans_unit_id` (`unit_id`),
  KEY `ix_duty_week_plans_id` (`id`),
  KEY `ix_duty_week_plans_week_start` (`week_start`),
  CONSTRAINT `duty_week_plans_ibfk_1` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`),
  CONSTRAINT `duty_week_plans_ibfk_2` FOREIGN KEY (`submitted_by_id`) REFERENCES `users` (`id`),
  CONSTRAINT `duty_week_plans_ibfk_3` FOREIGN KEY (`reviewed_by_id`) REFERENCES `users` (`id`),
  CONSTRAINT `duty_week_plans_ibfk_4` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `duty_week_plans`
--

LOCK TABLES `duty_week_plans` WRITE;
/*!40000 ALTER TABLE `duty_week_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `duty_week_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `education_materials`
--

DROP TABLE IF EXISTS `education_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `education_materials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_label` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `ix_education_materials_category` (`category`),
  KEY `ix_education_materials_id` (`id`),
  CONSTRAINT `education_materials_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `education_materials`
--

LOCK TABLES `education_materials` WRITE;
/*!40000 ALTER TABLE `education_materials` DISABLE KEYS */;
/*!40000 ALTER TABLE `education_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_items_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leadership_tasks`
--

DROP TABLE IF EXISTS `leadership_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leadership_tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `commander_role` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `commander_id` int NOT NULL,
  `commander_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_branch` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'toan_lu_doan',
  `assigned_unit_id` int DEFAULT NULL,
  `assigned_unit_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `urgency` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'thuong',
  `deadline` date DEFAULT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'dang_thuc_hien',
  `report_content` text COLLATE utf8mb4_unicode_ci,
  `reported_by_id` int DEFAULT NULL,
  `reported_by_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reported_at` datetime DEFAULT NULL,
  `review_note` text COLLATE utf8mb4_unicode_ci,
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `commander_id` (`commander_id`),
  KEY `reported_by_id` (`reported_by_id`),
  KEY `ix_leadership_tasks_commander_role` (`commander_role`),
  KEY `ix_leadership_tasks_target_branch` (`target_branch`),
  KEY `ix_leadership_tasks_urgency` (`urgency`),
  KEY `ix_leadership_tasks_assigned_unit_id` (`assigned_unit_id`),
  KEY `ix_leadership_tasks_id` (`id`),
  KEY `ix_leadership_tasks_status` (`status`),
  CONSTRAINT `leadership_tasks_ibfk_1` FOREIGN KEY (`commander_id`) REFERENCES `users` (`id`),
  CONSTRAINT `leadership_tasks_ibfk_2` FOREIGN KEY (`assigned_unit_id`) REFERENCES `units` (`id`),
  CONSTRAINT `leadership_tasks_ibfk_3` FOREIGN KEY (`reported_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leadership_tasks`
--

LOCK TABLES `leadership_tasks` WRITE;
/*!40000 ALTER TABLE `leadership_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `leadership_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `official_dispatches`
--

DROP TABLE IF EXISTS `official_dispatches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `official_dispatches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `direction` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'den',
  `dispatch_number` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `issuing_org` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receiving_org` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issued_date` date DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'moi',
  `classification` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mat',
  `note` text COLLATE utf8mb4_unicode_ci,
  `attachment_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_type` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `doc_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cong_van',
  `signer` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `page_count` int DEFAULT NULL,
  `security_level` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mat',
  `urgency` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'thuong',
  `archive_ref` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dispatch_direction_number` (`direction`,`dispatch_number`),
  KEY `created_by_id` (`created_by_id`),
  KEY `ix_official_dispatches_dispatch_number` (`dispatch_number`),
  KEY `ix_official_dispatches_id` (`id`),
  KEY `ix_official_dispatches_direction` (`direction`),
  KEY `ix_official_dispatches_status` (`status`),
  CONSTRAINT `official_dispatches_ibfk_1` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `official_dispatches`
--

LOCK TABLES `official_dispatches` WRITE;
/*!40000 ALTER TABLE `official_dispatches` DISABLE KEYS */;
/*!40000 ALTER TABLE `official_dispatches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cover_image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cho_duyet',
  `review_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviewed_by_id` int DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `classification` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noi_bo',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `author_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `summary` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_posts_slug` (`slug`),
  KEY `reviewed_by_id` (`reviewed_by_id`),
  KEY `author_id` (`author_id`),
  KEY `ix_posts_status` (`status`),
  KEY `ix_posts_id` (`id`),
  KEY `ix_posts_classification` (`classification`),
  KEY `ix_posts_is_featured` (`is_featured`),
  KEY `ix_posts_category` (`category`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`reviewed_by_id`) REFERENCES `users` (`id`),
  CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (33,'LỮ ĐOÀN THÔNG TIN 21 KỶ NIỆM 65 NĂM GIỮ VỮNG “MẠCH MÁU” LIÊN LẠC BIÊN CƯƠNG','hoat_dong_don_vi','<p><b>Kế thừa truyền thống vẻ vang</b></p><p>Trải qua 65 năm xây dựng, chiến đấu và trưởng thành (27/3/1961 – 27/3/2026), Lữ đoàn Thông tin 21 Bộ đội Biên phòng luôn khẳng định vị thế là lực lượng nòng cốt, giữ vững \"mạch máu\" thông tin liên lạc thông suốt, vững chắc trong mọi tình huống; phục vụ đắc lực cho công tác lãnh đạo, chỉ huy, quản lý và bảo vệ vững chắc chủ quyền an ninh biên giới quốc gia.</p><p><img src=\"/static/common/4c72c9917bed47fcadb1d277778419e3.jpg\" alt=\"\" class=\"rc-img rc-w-100 rc-center\"></p><h3>Dấu mốc tự hào và tri ân thế hệ đi trước</h3><p>Nhân dịp kỷ niệm 65 năm Ngày truyền thống, Lữ đoàn Thông tin 21 đã trang trọng tổ chức buổi gặp mặt truyền thống tại Hà Nội. Buổi gặp mặt là dịp ôn lại chặng đường vẻ vang, tri ân sâu sắc những cống hiến bền bỉ của các thế hệ cán bộ, chiến sĩ đi trước; đồng thời khẳng định bản lĩnh chính trị kiên định, tinh thần đoàn kết, chủ động sáng tạo và ý chí vượt khó vươn lên của người lính thông tin Biên phòng qua các thời kỳ.</p><h3>Phương châm hành động: “Kịp thời – Chính xác – Bí mật – An toàn”</h3><p>Phát huy truyền thống đơn vị Anh hùng, cán bộ, chiến sĩ Lữ đoàn Thông tin 21 hôm nay luôn khắc ghi lời dạy của Chủ tịch Hồ Chí Minh đối với bộ đội thông tin liên lạc:</p><ul><li><p><b>Kịp thời:</b> Bảo đảm cánh sóng luôn thông suốt 24/7, truyền đạt mệnh lệnh chỉ huy nhanh chóng, đáp ứng kịp thời các nhiệm vụ thường xuyên cũng như đột xuất.</p></li><li><p><b>Chính xác:</b> Tiếp nhận, xử lý và chuyển giao văn kiện, tín hiệu chuẩn xác tuyệt đối, không để xảy ra sai sót, nhầm lẫn.</p></li><li><p><b>Bí mật:</b> Giữ vững kỷ luật thông tin quân sự, chấp hành nghiêm các quy định về an toàn thông tin và bảo mật cơ yếu.</p></li><li><p><b>An toàn:</b> Làm chủ vũ khí, trang bị kỹ thuật công nghệ cao; bảo đảm an toàn tuyệt đối cho người, mạng lưới và phương tiện.</p></li></ul><h3>Vững bước tương lai</h3><p>Đứng trước yêu cầu, nhiệm vụ bảo vệ chủ quyền lãnh thổ trong tình hình mới và tiến trình xây dựng Quân đội hiện đại, Lữ đoàn Thông tin 21 tiếp tục đẩy mạnh phong trào Thi đua Quyết thắng, nâng cao chất lượng huấn luyện làm chủ khí tài thế hệ mới, quyết tâm hoàn thành xuất sắc mọi nhiệm vụ được giao, xứng đáng là lá chắn thông tin tin cậy nơi biên cương của Tổ quốc.</p>','/static/common/fa72586880e7427c977ac58521865aea.jpg','da_duyet',NULL,NULL,NULL,'cong_khai',1,1,'2026-09-03 22:20:59',NULL,'lu-doan-thong-tin-21-65-nam-giu-vung-mach-mau-lien-lac-bien-cuong','[]');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_kind` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'phong_ban',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_units_name` (`name`),
  KEY `ix_units_id` (`id`),
  KEY `ix_units_unit_kind` (`unit_kind`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'Tiểu đoàn 1','tieu_doan',NULL,1,'2026-08-30 19:22:37'),(3,'Đại đội 5','dai_doi',NULL,1,'2026-08-30 19:37:54'),(6,'Ban chỉ huy Lữ đoàn','bch_lu_doan','Lữ trưởng, Chính uỷ, các Phó Lữ trưởng, Phó Chính uỷ',1,'2026-08-30 21:26:25'),(7,'Cấp uỷ – Đảng bộ Lữ đoàn','cap_uy','Cấp uỷ, Đảng bộ Lữ đoàn',1,'2026-08-30 21:26:25'),(8,'Phòng Tham mưu','phong_ban','Cơ quan tham mưu — đầu mối nhận và triển khai nhiệm vụ tác chiến, huấn luyện, SSCĐ',1,'2026-08-30 21:26:25'),(9,'Phòng Chính trị','phong_ban','Cơ quan chính trị — đầu mối công tác đảng, công tác chính trị, tuyên huấn',1,'2026-08-30 21:26:25'),(10,'Phòng Hậu cần – Kỹ thuật','phong_ban','Cơ quan hậu cần – kỹ thuật — đầu mối bảo đảm vật chất, kỹ thuật, quân y',1,'2026-08-30 21:26:25'),(11,'Tiểu đoàn 2','tieu_doan','Đầu mối tiểu đoàn — nhận nhiệm vụ và báo cáo tiến độ',1,'2026-08-30 21:26:25'),(12,'Trạm bảo đảm','tram','Trạm bảo đảm thông tin',1,'2026-08-30 21:26:25'),(13,'Trung tâm 2','phong_ban','Trung tâm 2 — đầu mối trực thuộc',1,'2026-08-30 21:26:25'),(22,'Trạm Kiểm soát','tram','Trạm Kiểm soát thông tin liên lạc',1,'2026-09-06 10:59:41');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hashed_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int NOT NULL DEFAULT '5',
  `is_active` tinyint(1) NOT NULL,
  `clearance` tinyint(1) NOT NULL DEFAULT '0',
  `unit_id` int DEFAULT NULL,
  `directive_channel_access` tinyint(1) NOT NULL DEFAULT '0',
  `command_channel_access` tinyint(1) NOT NULL DEFAULT '0',
  `is_system` tinyint(1) NOT NULL DEFAULT '0',
  `must_change_password` tinyint(1) NOT NULL DEFAULT '0',
  `military_rank` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_users_username` (`username`),
  KEY `ix_users_id` (`id`),
  KEY `ix_users_unit_id` (`unit_id`),
  CONSTRAINT `fk_users_unit` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2b$12$aV77jHsrBjJhss51ieW6OuNqn9NOnkSWd8U28KyiLkVMcGT424YjK','Quản trị hệ thống',0,1,1,NULL,0,0,1,0,NULL,NULL),(159,'lu_truong','$2b$12$B.Aj49mBL7sXoaoVORcSyuldzvQD71v.P1Egf31VdEULL8e5KKFHy','Nguyễn Văn Thắng',1,1,1,6,1,1,0,0,'Đại tá','Lữ đoàn trưởng (Chỉ đạo chung chính quyền)'),(160,'chinh_uy','$2b$12$gzAz7oYsh1KUY0H/f8tkye7YTn.32aM.Ke3XCvMrv2uRM1ddvlfbq','Trần Văn Nam',1,1,1,6,1,1,0,0,'Đại tá','Chính uỷ Lữ đoàn (Chỉ đạo công tác Đảng, CTĐ-CTCT)'),(161,'lu_pho_tm','$2b$12$B/sk139tI/fIGbDcdWyp4.XuqnhgueXujQzevIGlODFRubqYuHl1G','Lê Văn Hải',2,1,1,6,1,1,0,0,'Thượng tá','Phó Lữ đoàn trưởng kiêm Tham mưu trưởng'),(162,'lu_pho_hckt','$2b$12$W5K0Ovh/mIJ4wRWrFg9X1OvqcXQ2cS7.i/ynRXLX47AqABJS1wyDu','Hoàng Đức Long',2,1,1,6,1,1,0,0,'Thượng tá','Phó Lữ đoàn trưởng (Chỉ đạo Hậu cần - Kỹ thuật)'),(163,'pho_chinh_uy','$2b$12$m/DTrPJdND4h6RnjBeiMxuHbV/N/.Y9lx6KKPRj6iQ9Yvih21qB3C','Phạm Văn Hùng',2,1,1,6,1,1,0,0,'Thượng tá','Phó Chính uỷ (Chỉ đạo các tổ chức quần chúng)'),(164,'tm_truong','$2b$12$raRUCUcyiOl2D1VnWzo.s.dMGoIjv3hYXMnJuJu1L16kwubhfnBy2','Đỗ Văn Cường',3,1,1,8,1,0,0,0,'Trung tá','Trưởng phòng Tham mưu'),(165,'tro_ly_tac_chien','$2b$12$H0XbBZdGAWyPdolFQ//TSuXnNtxPFzardhjgYQ0oGQ8V8Lr99IoEK','Vũ Tuấn Anh',4,1,1,8,1,0,0,0,'Thiếu tá','Trợ lý Tác chiến - Thông tin liên lạc'),(166,'ct_truong','$2b$12$hM2lV7BHYKcjAODnMreHYuJvZD1LYY2Fwdjp8Q2WaZydPaED8YW5y','Nguyễn Hoàng Nam',3,1,1,9,1,0,0,0,'Trung tá','Chủ nhiệm Chính trị'),(167,'tro_ly_tuyen_huan','$2b$12$/2Kr/UBuInnMsz1HyYphhO4MBc/xVp/scaWcGB6.Ke7RtSjdSYOWq','Lê Hồng Phúc',4,1,1,9,1,0,0,0,'Đại uý','Trợ lý Tuyên huấn - CTĐ-CTCT'),(168,'hckt_truong','$2b$12$I1HLRdqKtAwbgx9LPGSBN.cfXxdeb4ube1vJ9Kg1MwQ4fguzjK1fK','Bùi Văn Toàn',3,1,1,10,1,0,0,0,'Trung tá','Chủ nhiệm Hậu cần – Kỹ thuật'),(169,'tro_ly_quan_khi','$2b$12$j2roCxrGncnUmDzH0XYh0.ilkVgdVPNUUP.1dmiTFAbjDpdqfQOOW','Trần Đình Trọng',4,1,1,10,1,0,0,0,'Đại uý','Trợ lý Quân khí - Xe máy TTLL'),(170,'d1_truong','$2b$12$ipYmxTf65OSOr8qnMm6JE.3IAet2Lu.Q7gvlhHDKV1FM.sStMX.Qy','Hoàng Văn Dũng',3,1,1,1,1,0,0,0,'Thiếu tá','Tiểu đoàn trưởng Tiểu đoàn 1'),(171,'d1_chinh_tri_vien','$2b$12$ixXm.z8wV3FrzX3K31ChTebeNXYSBRZxe6G/qH.9Fw82uu05R3tre','Trịnh Xuân Hưng',3,1,1,1,1,0,0,0,'Thiếu tá','Chính trị viên Tiểu đoàn 1'),(172,'d2_truong','$2b$12$j39ZDnuVGBhz0Z5zthIQ0.5kEhiIKSio/BfvGhK3V0faWQDECD9LW','Ngô Văn Hùng',3,1,1,11,1,0,0,0,'Thiếu tá','Tiểu đoàn trưởng Tiểu đoàn 2'),(173,'c5_truong','$2b$12$HHSrrKdxDlXkUDeqnTH8yO4mJlN1jvewxdO3dRi8loaH0eMGuponu','Vũ Đình Phong',3,1,1,3,1,0,0,0,'Đại uý','Đại đội trưởng Đại đội 5 (Trực thuộc)'),(174,'tt2_truong','$2b$12$O/OxxLkl.CAX0Xck4Bq5YOmmY0kJfUZ9UxggKJMvJJ4YNxoE2nKEK','Nguyễn Trọng Tấn',3,1,1,13,1,0,0,0,'Thiếu tá','Giám đốc Trung tâm 2'),(175,'tram_kiem_soat','$2b$12$lW1bPn08sueorg3WJyC68.Yt5fgvCCVB9jhfnreozic0eOGoi.76e','Đặng Thành Vinh',3,1,1,22,1,0,0,0,'Đại uý','Trạm trưởng Trạm Kiểm soát TTLL'),(176,'tram_bao_dam','$2b$12$XX3dpUr2Kg1xRRKKPUXE9.N8pRGBbPRBmQSVoIZBjfNIR3n2nLbXu','Phan Văn Khánh',3,1,1,12,1,0,0,0,'Đại uý','Trạm trưởng Trạm bảo đảm kỹ thuật TTLL');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'ludoan_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-06 13:59:26
